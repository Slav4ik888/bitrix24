module.exports = [
  { ID: "4490", TITLE: "СпецМосГорСтрой", RESULT: true, RETURN: "СпецМосГорСтрой" },
  { ID: "4491", TITLE: "СпецМос_ГорСтрой", RESULT: false, RETURN: "СпецМос_ ГорСтрой" },
  { ID: "4492", TITLE: "СпецМос_ ГорСтрой", RESULT: true, RETURN: "СпецМос_ ГорСтрой" },
  { ID: "4493", TITLE: "_ СпецМосГорСтрой", RESULT: true, RETURN: "_ СпецМосГорСтрой" },
  { ID: "4494", TITLE: "_СпецМосГорСтрой", RESULT: false, RETURN: "_ СпецМосГорСтрой" },
  { ID: "4495", TITLE: "_", RESULT: true, RETURN: "_" },
  { ID: "4496", TITLE: "", RESULT: true, RETURN: "" },
];